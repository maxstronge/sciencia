This folder gives an example how to plot the data.

This is useful if you are struggling with trying to figure out how to take
the dead time into account. 

It uses iPython, so you'll have to install that first.
You'll need:

python
numpy
spicy
matplotlib

These are most easily installed using pip. 

example:
install pip on your computer, then from the terminal (command propmt)
pip install scipy
...
