# CosmicWatch-Desktop-Muon-Detector
This repository if for the supplementary material used to build the CosmicWatch Desktop Muon Detectors V2

This one includes the microSD card reader and coincidence connection.

Website: http://www.cosmicwatch.lns.mit.edu/

YouTube tutorial: https://www.youtube.com/watch?v=e4IXzNiNxgU

Paper: https://arxiv.org/abs/1801.03029
