var searchData=
[
  ['hardspifastinterface_21',['HardSpiFastInterface',['../classace__spi_1_1HardSpiFastInterface.html#ad370f650886b66891b18bbc1747cfc9b',1,'ace_spi::HardSpiFastInterface']]],
  ['hardspiinterface_22',['HardSpiInterface',['../classace__spi_1_1HardSpiInterface.html#a28b7e98dd0c1db6ec0e0882124bb9a12',1,'ace_spi::HardSpiInterface']]]
];
