This folder contains the file used to:
	1. record data from the detector to the computer
	2. save data from the sd card
	3. remove the data from the sd card

This code was written using python 2.7

Running it requires two libraries:
	1. pyserial (used to read data through the serial port)	
	2. tornado (used to connect to the CosmicWatch website)

After installing libraries, simply plug the detector into a USB port, run the import.py
python script, and you will be prompted on what you want to do.