var searchData=
[
  ['simplespifastinterface_15',['SimpleSpiFastInterface',['../classace__spi_1_1SimpleSpiFastInterface.html',1,'ace_spi']]],
  ['simplespiinterface_16',['SimpleSpiInterface',['../classace__spi_1_1SimpleSpiInterface.html',1,'ace_spi']]]
];
