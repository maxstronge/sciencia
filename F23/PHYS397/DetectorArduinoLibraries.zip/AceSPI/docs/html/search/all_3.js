var searchData=
[
  ['hardspifastinterface_5',['HardSpiFastInterface',['../classace__spi_1_1HardSpiFastInterface.html',1,'ace_spi::HardSpiFastInterface&lt; T_SPI, T_LATCH_PIN, T_CLOCK_SPEED &gt;'],['../classace__spi_1_1HardSpiFastInterface.html#ad370f650886b66891b18bbc1747cfc9b',1,'ace_spi::HardSpiFastInterface::HardSpiFastInterface()']]],
  ['hardspiinterface_6',['HardSpiInterface',['../classace__spi_1_1HardSpiInterface.html',1,'ace_spi::HardSpiInterface&lt; T_SPI, T_CLOCK_SPEED &gt;'],['../classace__spi_1_1HardSpiInterface.html#a28b7e98dd0c1db6ec0e0882124bb9a12',1,'ace_spi::HardSpiInterface::HardSpiInterface()']]]
];
